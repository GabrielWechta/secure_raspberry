#!/bin/sh
# Run with root privileges

vncserver :2 -geometry 1920x1080 -depth 24 -dpi 96

echo "done."